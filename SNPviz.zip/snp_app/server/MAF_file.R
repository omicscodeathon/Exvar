#libraries
library(maftools)
library(ggplot2)
#file
laml_tab <- read.delim("demo/tcga_laml.maf", sep = "\t")
laml_tab[1:2, ]

#mutation per sample
tbl <- table(laml_tab$Tumor_Sample_Barcode)
hist(tbl, breaks = 10, xlab = "Mutations")   # = plot

#
laml <- read.maf("demo/tcga_laml.maf.gz")
class(laml)
sample_sum <- getSampleSummary(laml)
sample_sum[1:2, ]

#Mutation classes in each sample

var_to <- sample_sum$total
names(var_to) <- sample_sum$Tumor_Sample_Barcode
sample_sum <- dplyr::select(sample_sum, -total)
melt_dat <- reshape2::melt(sample_sum, id = "Tumor_Sample_Barcode")
melt_dat[1:3, ]

#Mutation classes in each sample
melt_dat$totalVar <- var_to[match(melt_dat$Tumor_Sample_Barcode, names(var_to))]
melt_dat$prop <- melt_dat$value/melt_dat$totalVar
head(melt_dat)


#plot : Mutation classes in each sample
ggplot(melt_dat,aes(x=Tumor_Sample_Barcode,y=value,fill=variable))+
  geom_bar(stat='identity',position = 'stack')+
  labs(x="",y="Mutations",fill="")+
  theme(axis.text.x=element_blank())

ggplot(melt_dat,aes(x=Tumor_Sample_Barcode,y=prop,fill=variable))+
  geom_bar(stat='identity',position = 'stack')+
  labs(x="",y="Proportion",fill="")+
  theme(axis.text.x=element_blank())

#How many mutations in each gene
gene_sum <- getGeneSummary(laml)
gene_sum[1:2, ]

## Functional analysis of mutations ------------
lollipopPlot(maf = laml, 
             gene = 'NRAS', 
             AACol = 'Protein_Change', 
             showMutationRate = TRUE,
             labelPos = "all")


# Interaction between mutations
#Oncoplot for top 5 mutated genes   = plot   = gene number input
oncoplot(maf = laml, top = 5)


#Pathway analysis
OncogenicPathways(maf = laml)
#Mutations enriched in pathways ?
PlotOncogenicPathways(maf = laml, pathways = "RTK-RAS")  #pathway = input

# Mutation Signatures
# Ti/Tv plot
laml.titv = titv(maf = laml, plot = FALSE, useSyn = TRUE)
plotTiTv(res = laml.titv)

#Trinucleotide matrix
library(BSgenome.Hsapiens.UCSC.hg19, quietly = TRUE)
laml.tnm = trinucleotideMatrix(maf = laml,
                               prefix = 'chr', 
                               add = TRUE, 
                               ref_genome = "BSgenome.Hsapiens.UCSC.hg19")

dim(laml.tnm$nmf_matrix)
laml.tnm$nmf_matrix[1, ]



### viz Trinucleotide pattern in only one sample example "TCGA-AB-3009"
tarSam_triNuc <- laml.tnm$nmf_matrix["TCGA-AB-3009", ]
tarSam_triNuc[1:2]

yd <- data.frame(triNuc = names(tarSam_triNuc), count = tarSam_triNuc, stringsAsFactors = FALSE)
yd$cat <- gsub("(.*)\\[(.*)\\](.*)", "\\2", yd$triNuc)
yd$num <- seq(1, length(yd$triNuc))

ggplot(yd,aes(x=num,y=count,fill=cat))+
  geom_bar(stat='identity')+
  labs(x="",y="Counts",fill="")+
  theme(axis.text.x=element_blank())


### Estimate number of signautres ---------------              +++++++++++++++++++++++
library('NMF')
laml.sign <- estimateSignatures(mat = laml.tnm,
                                nTry = 6,
                                pConstant = 0.1,
                                parallel = 1)

# Extract signautres

laml.sig.ext <- extractSignatures(mat = laml.tnm, 
                                  n = 3,
                                  pConstant = 0.1,
                                  parallel = 1)
laml.sig.ext$signatures[1:5,] # use for mapping to mutational signature database

# What do the signtures stand for?
# Map to mutational signatures databases eg. COSMIC
laml.og30.cosm = compareSignatures(nmfRes = laml.sig.ext,
                                   sig_db = "legacy")
laml.og30.cosm$cosine_similarities[,1:5]

# Map the signatures to COSMIC database
pheatmap::pheatmap(mat = laml.og30.cosm$cosine_similarities, cluster_rows = FALSE)
# plot signatures ~ COSMIC
plotSignatures(nmfRes = laml.sig.ext, 
               title_size = 1.2,
               contributions = FALSE,
               show_title = TRUE,
               sig_db = 'legacy')


#Map the signatures to SBS database
laml.sign.sbs = compareSignatures(nmfRes = laml.sig.ext, sig_db = "SBS")
laml.sign.sbs$cosine_similarities[, 1:5]
# plot
pheatmap::pheatmap(mat = laml.sign.sbs$cosine_similarities, cluster_rows = FALSE)

#plot signatures ~ SBS

plotSignatures(nmfRes = laml.sig.ext, 
               title_size = 1.2,
               contributions = FALSE,
               show_title = TRUE,
               sig_db = 'SBS')


# Mutational signautes in each sample
lotSignatures(nmfRes = laml.sig.ext,
              title_size = 0.8,
              contributions = TRUE,
              show_title = TRUE)

# Enrichment analysis
laml.se = signatureEnrichment(maf = laml, 
                              sig_res = laml.sig.ext)

#Genes associated with signatures
laml.se$groupwise_comparision[1:2, ]
# plot
plotEnrichmentResults(enrich_res = laml.se, pVal = 0.05)











