#load libraries
#source("global.R", local = TRUE)
#library(shiny)
#library(shinydashboard)
#library(waiter)
#library(DT)

# UI
ui <- fluidPage(
  
  dashboardPage(
    dashboardHeader(title = "CNVviz"),
    dashboardSidebar(
      sidebarMenu(
        menuItem("Home", tabName = "DataImport", icon = icon("dna")),
        menuItem("CNV Data", tabName = "CNV", icon = icon("dna"))
        #, menuItem("eQTL", tabName = "eqtl", icon = icon("dna"))
      )
    ),
    dashboardBody(use_waiter(),
                  tabItems(
                    
                    #### ------------------ Import data dashboard -------------------###############
                    tabItem(tabName = "DataImport", h2("Visualize SNPs data"),
                            #start fluidrow vcf file load
                            fluidRow(
                              # start box right (contain input) ==> read csv file
                              box(status = "primary", width = 3,
                                  solidHeader = TRUE,
                                  collapsible = TRUE,
                                  title = "Import File",
                                  br(),
                                  "Import the variant data vcf file here",
                                  br(),
                                  fileInput("vcf_file", label = "Upload vcf file"),
                              ), # end box right
                              
                              # start box left (contain output) ==> ouput 
                              box(title = "Visualize variantsfile", width = 9, height = 600, 
                                  "vcf file see", br(),
                                  DT::dataTableOutput("data_matrix_vcf")
                              ) # end box left 
                              
                            ) # end fluid row 1
                    ), #import tabitem
                    
                    #### ------------------ SNP dashboard -------------------###############
                    tabItem(tabName = "CNV", h2("Visualize SNPs data"),
                            fluidRow(width =12,
                                     tabBox(title = "Visualize CNV data", width =12,
                                            ### multiple plots in same box
                                            selected = "plot1",
                                            tabPanel("plot1",  "plot1",
                                                     br(),
                                                     echarts4rOutput("plot1", height = 500))
                                            ,tabPanel("plot2",  "plot2",
                                                      br(),
                                                      plotOutput("plot2", height = 500)) 
                                            ,tabPanel("plot3",  "plot3",
                                                      br(),
                                                      plotOutput("plot3", height = 500))
                                     ) # end tabbox
                            ) #end see vcf fluid
                    ), #snp tabitem
                    
                    #### ------------------ AAC dashboard -------------------###############
                    tabItem(tabName = "eqtl", h2("eqtl"),
                            box(title = "Visualize eQTL data", width =12,
                              "eQTL_plot",  "eQTL_plot",
                              br(),
                              echarts4rOutput("eQTL_plot", height = 500)
                            )
                            )
                  ) #tabitems
    ) #body
  ) #dashboard
  
) # fluidpage


# Server 
server <- function(input, output, session) {
  
  
  # SNPs interface vcf_file
  ## read vcf file
  file2_data <- reactive({
    file3 <- input$vcf_file
    if(!is.null(file3)){read.csv(file3$datapath)}
  })
  
  
  # start box 1 csv file  >>>>    how to skip the info lines !!!!!
  #output$data_matrix_vcf <- DT::renderDataTable({
  #  req(file2_data())
  #  file2_data()
  #}) 
  ####---------------------- filter   ---------------------------####
  #source("server/variant_filter.R", local = TRUE)
  ####---------------------- snp types visualization   ---------------------------####
 # source("server/cnv_viz.R", local = TRUE)
  # start box 1 csv file  >>>>    how to skip the info lines !!!!!
  output$data_matrix_vcf <- DT::renderDataTable({
    req(snp_vcf_data)
    snp_vcf_data
  }) 
  ####---------------------- eQTL  ---------------------------####
  #source("server/eQTL", local = TRUE)

}

# Run the application 
shinyApp(ui = ui, server = server)
