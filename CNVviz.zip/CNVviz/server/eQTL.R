#CNV-expression association analysis

rseq.file <- file.path(data.dir, "counts_cleaned.txt")
rcounts <- read.delim(rseq.file, row.names=1, stringsAsFactors=FALSE)
rcounts <- as.matrix(rcounts)
dim(rcounts)

rcounts[1:5, 1:5]

library(SummarizedExperiment)
rse <- SummarizedExperiment(assays=list(rcounts=rcounts), 
                            rowRanges=granges(sel.genes)[rownames(rcounts)])
rse

res <- cnvEQTL(cnvrs, grl, rse, window="1Mbp", verbose=TRUE)

res[2]
r <- GRanges(names(res)[2])
ds <- as.data.frame(r)
#plot
output$eQTL_plot <- renderPlot({
  plotEQTL(cnvr=r, genes=res[[2]], genome="hg19", cn="CN1") 
})

#Error in FUN(X[[i]], ...) : Invalid chromosome identifier 'GJ058256.1'
#Please consider setting options(ucscChromosomeNames=FALSE) to allow for arbitrary chromosome identifiers.


Gviz::plotTracks
cnvr <- GRanges("chr1:7908902-8336254")
genes <- c("chr1:8021714-8045342:+", "chr1:8412464-8877699:-")
names(genes) <- c("PARK7", "RERE")
genes <- GRanges(genes)
genes$logFC.CN1 <- c(-0.635, -0.728)
genes$AdjPValue <- c(8.29e-09, 1.76e-08)
plotEQTL(cnvr, genes, genome="hg19", cn="CN1")
