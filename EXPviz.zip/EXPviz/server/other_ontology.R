#-------------------------------------------------

#https://bioc.ism.ac.jp/packages/3.7/bioc/vignettes/enrichplot/inst/doc/enrichplot.html#heatmap-like-functional-classification
library(clusterProfiler)
data(geneList, package="DOSE")
de <- names(geneList)[abs(geneList) > 2]
ego <- enrichGO(de, OrgDb = "org.Hs.eg.db", ont="BP", readable=TRUE)

library(enrichplot)
goplot(ego)

library(enrichplot)
#GO DAG graph
goplot(BP_up_go)
#dotplot
dotplot(BP_up_go, showCategory=30)


#
go <- enrichGO(upgene, OrgDb = "org.Hs.eg.db", ont="all")
dotplot(BP_up_go, split="ONTOLOGY") + facet_grid(ONTOLOGY~., scale="free") # eror

#Gene-Concept Network
## remove redundent GO terms  # eror
ego2 <- simplify(BP_up_go)
cnetplot(ego2, foldChange=geneList)
cnetplot(ego2, foldChange=geneList, circular = TRUE, colorEdge = TRUE)

#UpSet Plot
upsetplot(ego)

#Heatmap-like functional classification
heatplot(ego2)
heatplot(ego2, foldChange=geneList)

#Enrichment Map
emapplot(ego2)

#ridgeline plot for expression distribution of GSEA result
kk <- gseKEGG(upgenes_list, nPerm=10000)
ridgeplot(kk)

#running score and preranked list of GSEA result
gseaplot(kk, geneSetID = 1, by = "runningScore", title = kk$Description[1])
gseaplot(kk, geneSetID = 1, by = "preranked", title = kk$Description[1])
gseaplot(kk, geneSetID = 1, title = kk$Description[1])
