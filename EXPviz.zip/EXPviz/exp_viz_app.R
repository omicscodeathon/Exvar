#load libraries
#source("global.R", local = TRUE)

# UI
ui <- fluidPage(
  
  dashboardPage(
    dashboardHeader(title = "EXPviz"),
    dashboardSidebar(
      sidebarMenu(
        menuItem("Home", tabName = "Home"),
        menuItem("ImportData", tabName = "ImportData", icon = icon("dna")),
        menuItem("Expression", tabName = "Expression", icon = icon("dna")),
        menuItem("Ontology", tabName = "Ontology", icon = icon("dna"))
      )

    ),
    dashboardBody(use_waiter(),
                  tabItems(
                    #### ------------------ home dashboard -------------------###############
                    tabItem(tabName = "Home", h2("home tab content")),
                    
                    #### ------------------ expression dashboard -------------------###############
                    tabItem(tabName = "ImportData",
                            h2("Visualize genetic expression data"),
                            #start fluidrow csv file load
                            fluidRow(
                              # start box right (contain input) ==> read csv file
                              box(status = "primary", width = 3,
                                  solidHeader = TRUE,
                                  collapsible = TRUE,
                                  title = "Import File",
                                  br(),
                                  "Import the count data csv file here",
                                  br(),
                                  fileInput("csv_file", label = "Upload csv file"),
                              ), # end box right
                              
                              # start box left (contain output) ==> ouput 
                              box(title = "Visualize Count file", width = 9, height = 600, 
                                  "csv file see", br(),
                                  DT::dataTableOutput("data_matrix_df")
                              ) # end box left 
                              
                            ), # end fluid row 1
                            
                            #start fluid row 2 : count viz
                            fluidRow(
                              
                              # start bow right
                              tabBox(title = "Read Count before log2 transformation", width = 12,
                                     ### multiple plots in same box
                                     selected = "Read_Count1",
                                     
                                     tabPanel("Read_Count1", "Read Count before log2 transformation", 
                                              br(),
                                              plotOutput("read_count1", height = 300),
                                              plotOutput("read_count2", height = 300))),
                              tabBox(title = "Read Count after log2 transformation", width = 12,
                                     ### multiple plots in same box
                                     selected = "Read_Count2",
                                     
                                     tabPanel("Read_Count2", "Read Count after log2 transformation",
                                              br(),
                                              plotOutput("log_transformation1", height = 300),
                                              plotOutput("log_transformation2", height = 300)),
                                     tabPanel("density plot ",  "density plot ",
                                              br(),
                                              plotOutput("density_plot")),
                                              
                                     tabPanel("scatter plot ",  "scatter plot ",
                                                       br(),
                                                       plotOutput("scatter_plot"))
                                                               
                                     
                                     
                              ) # end tabbox 
                              
                            ),
                            
                            
      
                    ), # expression tab item
                    
                    #### ------------------ Expression dashboard -------------------###############
                    tabItem(tabName = "Expression", h2("expression tab content"),
                            #                            # start fluid exp
                            fluidRow(
                              
                              box(status = "primary", width = 3,
                                  solidHeader = TRUE,
                                  collapsible = TRUE,
                                  title = "Import metadata  File",
                                  br(),
                                  "Import the metadata csv file here",
                                  br(),
                                  fileInput("metadata_file", label = "Upload metadata csv file"),
                              ), # end box 
                              box(status = "info", width = 9,
                                  solidHeader = TRUE,
                                  collapsible = TRUE,
                                  title = "expression",
                                  br(),
                                  "Button here to fdefine groups",
                                  br(),
                                  "Button here to filter p and log fc val",
                                  br(),
                                  "Button here run expression analysis"
                                  
                              ), # end box 
                            ),
                            
                            fluidRow(width =12,
                                     tabBox(title = "Visualize expression data", width =12,
                                            ### multiple plots in same box
                                            selected = "PCA",
                                            tabPanel("PCA",  "PCA plot",
                                                     br(),
                                                     plotOutput("pca_plot", height = 500)),
                                            
                                            tabPanel("volcano", "Volcano plot",
                                                     br(),
                                                     plotOutput("volcano_plot", height = 500)),
                                            tabPanel("MA", "MA plot",
                                                     br(),
                                                     plotOutput("ma_plot", height = 500)),
                                            tabPanel("Heatmap", "Heatmap",
                                                     br(),
                                                      "Heatmap of all expressed genes",
                                                     br(),
                                                     "The heatmap need 2 minutes to load.",
                                                     plotOutput("heatmap", height = 500)),
                                            tabPanel("HeatmapDEGs", "Heatmap of DEGs",
                                                     br(),
                                                     "Heatmap of differentially expressed genes",
                                                     br(),
                                                     "The heatmap need 2 minutes to load.",
                                                     plotOutput("heatmap_degs", height = 500))
                                            
                                     ) # end tabbox
                            ) # end fluid exp
                            ),
                    #### ------------------ Ontology dashboard -------------------###############
                    tabItem(tabName = "Ontology", h2("ontology tab content"),
                            #ontology
                            fluidRow(width =12,
                                     #BP
                                     tabBox(title = "Biological Processes", width =12,
                                            ### multiple plots in same box
                                            selected = "Braplot1",
                                            tabPanel("Barplot1",  "BP Barplot",
                                                     br(),
                                                     plotOutput("BP_barplot", height = 500)),
                                            
                                            tabPanel("Dotplot", "BP dotplot",
                                                     br(),
                                                     plotOutput("BP_dotplot", height = 500))
                                     ), # end tabbox
                                     #MF
                                     tabBox(title = "Molecular Functions", width =12,
                                            ### multiple plots in same box
                                            selected = "Braplot2",
                                            tabPanel("Barplot2",  "MF Barplot",
                                                     br(),
                                                     plotOutput("MF_barplot", height = 500)),
                                            
                                            tabPanel("Dotplot", "MF dotplot",
                                                     br(),
                                                     plotOutput("MF_dotplot", height = 500))
                                     ), # end tabbox
                                     #CC
                                     tabBox(title = "Cellular Compenent", width =12,
                                            ### multiple plots in same box
                                            selected = "Braplot3",
                                            tabPanel("Barplot3",  "CC Barplot",
                                                     br(),
                                                     plotOutput("Cc_barplot", height = 500)),
                                            
                                            tabPanel("Dotplot", "Cc dotplot",
                                                     br(),
                                                     plotOutput("CC_dotplot", height = 500))
                                     ) # end tabbox
                            ) #end see vcf fluid
                    )
                    
                  ) #tabitems
    ) #body
  ) #dashboard
  
) # fluidpage


# Server 
server <- function(input, output, session) {
  
  #### ------------------ expression dashboard -------------------###############
  ## read count data csv file
  file_data <- reactive({
    file1 <- input$csv_file
    if(!is.null(file1)){read.csv(file1$datapath)}
  })
  
  # start box 1 csv file
  output$data_matrix_df <- DT::renderDataTable({
    req(file_data())
    file_data()
  }) 
  ## read metadat data file
  meta_file <- reactive({
    file2 <- input$metadata_file
    if(!is.null(file2)){read.csv(file2$datapath)}
  })
  
  # expression interface
  ####---------------------- viz count data   ---------------------------####
  source("server/count_viz.R", local = TRUE)
  ####---------------------- viz exp data   ---------------------------####
  source("server/exp_viz.R", local = TRUE)
  ####---------------------- Ontology analysis   ---------------------------####
  source("server/updateontology.R", local = TRUE)

}

# Run the application 
shinyApp(ui = ui, server = server)
